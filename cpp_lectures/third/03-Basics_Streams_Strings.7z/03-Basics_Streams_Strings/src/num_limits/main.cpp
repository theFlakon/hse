﻿/*! \file       main.cpp
 *  \author     Sergey Shershakov
 *  \version    0.1
 *  \date       22.01.2026
 *
 *  Исследование диапазонов значений встроенных типов данных с помощью C- и C++- подходов.
 */

#include <iostream>
#include <climits> // for INT_MIN
#include <limits> // for numeric_limits<>

int main()
{
    std::cout << "Hello world!\n";

    // exploring limits with C-style approach:
    std::cout << "Size of int is " << sizeof(int) << " bytes\n";
    std::cout << "  its MIN value is " << INT_MIN
              << ", and its MAX value is " << INT_MAX << "\n\n";

    // exploring limits with C++-style approach:
    std::cout << "Limits defined by numeric_limits<> type:\n";
    std::cout << "  int MIN value is " << std::numeric_limits<int>::min()
              << ", and its MAX value is "
              << std::numeric_limits<int>::max() << "\n";


    return 0;
}
